<?php

/**
 * @file
 * controls load theme.
 */

include_once drupal_get_path('theme', 'tb_sirate') . '/inc/preprocess_functions.inc';
